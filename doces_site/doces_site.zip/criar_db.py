import sqlite3
import os

DB_NAME = "database.db"

if os.path.exists(DB_NAME):
    os.remove(DB_NAME)

conn = sqlite3.connect(DB_NAME)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE produtos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    descricao TEXT NOT NULL,
    preco REAL NOT NULL,
    imagem TEXT NOT NULL
);
""")

produtos = [
    ("Brigadeiro Gourmet", "Brigadeiro feito com chocolate belga.", 2.50, "img/brigadeiro.jpg"),
    ("Beijinho de Coco", "Doce de leite condensado com coco ralado.", 2.00, "img/beijinho.jpg"),
    ("Trufa Artesanal", "Trufa recheada com ganache de maracujá.", 4.00, "img/trufa.jpg"),
    ("Brownie de Ninho", "Brownie recheado com creme de leite Ninho.", 5.00, "img/brownie.jpg"),
    ("Caixa Sortida", "Seleção especial de 12 doces variados.", 25.00, "img/caixa.jpg")
]

cursor.executemany(
    "INSERT INTO produtos (nome, descricao, preco, imagem) VALUES (?, ?, ?, ?)",
    produtos
)

conn.commit()
conn.close()

print("✅ Banco de dados criado e populado com sucesso!")
